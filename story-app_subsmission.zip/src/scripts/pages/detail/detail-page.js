import { fetchStoryById } from '../../data/api';
import { parseActivePathname } from '../../routes/url-parser';

class DetailPage {
  constructor() {
    this._story = null;
  }

  async render() {
    const container = document.createElement('section');
    container.innerHTML = `<div id="detail-container"><p>Loading...</p></div>`;
    return container;
  }

  async afterRender() {
    const parsed = parseActivePathname();
    const id = parsed.id;
    if (!id) {
      document.getElementById('detail-container').innerHTML = '<p>Story ID tidak ditemukan pada URL.</p>';
      return;
    }
    try {
      const token = localStorage.getItem('authToken');
      const res = await fetchStoryById(id, token);
      const story = res.story || res;
      document.getElementById('detail-container').innerHTML = `
        <article class="story-card">
          <img src="${story.photoUrl || './public/images/logo.png'}" alt="${story.name || 'story image'}"/>
          <h3>${story.name || ''}</h3>
          <p>${story.description || ''}</p>
          <p><small>Dibuat: ${new Date(story.createdAt || Date.now()).toLocaleString()}</small></p>
        </article>
      `;
    } catch (err) {
      console.error(err);
      document.getElementById('detail-container').innerHTML = '<p>Gagal memuat detail story.</p>';
    }
  }
}

export default DetailPage;
