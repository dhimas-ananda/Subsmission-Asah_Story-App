import { loginUser } from '../../data/api';

class LoginPage {
  async render() {
    const container = document.createElement('section');
    container.innerHTML = `
      <h2>Login</h2>
      <form id="login-form" aria-label="Login form">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required />
        <label for="password">Password</label>
        <input id="password" name="password" type="password" required minlength="8" />
        <div style="margin-top:.5rem">
          <button type="submit">Login</button>
        </div>
      </form>
      <div id="login-message" aria-live="polite"></div>
    `;
    return container;
  }

  async afterRender() {
    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      try {
        const res = await loginUser({ email, password });
        if (res.error) {
          document.getElementById('login-message').textContent = res.message || 'Login gagal';
        } else if (res.loginResult && res.loginResult.token) {
          localStorage.setItem('authToken', res.loginResult.token);
          localStorage.setItem('userName', res.loginResult.name || '');
          document.getElementById('login-message').textContent = 'Login berhasil.';
          // navigate to home
          window.location.hash = '#/';
        } else {
          document.getElementById('login-message').textContent = 'Login: respons tidak diharapkan';
        }
      } catch (err) {
        console.error(err);
        document.getElementById('login-message').textContent = 'Terjadi kesalahan saat login.';
      }
    });
  }
}

export default LoginPage;
