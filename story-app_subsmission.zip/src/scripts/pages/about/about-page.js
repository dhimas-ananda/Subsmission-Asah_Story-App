class AboutPage {
  async render() {
    const container = document.createElement('section');
    container.innerHTML = `
      <h2>About</h2>
      <p>This is a submission project for Dicoding class — Story App (Accessibility, Transitions, Media, Map).</p>
    `;
    return container;
  }
}

export default AboutPage;
