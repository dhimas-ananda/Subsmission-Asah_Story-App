import { registerUser } from '../../data/api';

class RegisterPage {
  async render() {
    const container = document.createElement('section');
    container.innerHTML = `
      <h2>Register</h2>
      <form id="register-form" aria-label="Register form">
        <label for="name">Name</label>
        <input id="name" name="name" required />
        <label for="email">Email</label>
        <input id="email" name="email" type="email" required />
        <label for="password">Password (min 8 chars)</label>
        <input id="password" name="password" type="password" required minlength="8" />
        <div style="margin-top:.5rem">
          <button type="submit">Register</button>
        </div>
      </form>
      <div id="register-message" aria-live="polite"></div>
    `;
    return container;
  }

  async afterRender() {
    document.getElementById('register-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      try {
        const res = await registerUser({ name, email, password });
        if (res.error) {
          document.getElementById('register-message').textContent = res.message || 'Register gagal';
        } else {
          document.getElementById('register-message').textContent = 'User created. Silakan login.';
          window.location.hash = '#/login';
        }
      } catch (err) {
        console.error(err);
        document.getElementById('register-message').textContent = 'Terjadi kesalahan saat register.';
      }
    });
  }
}

export default RegisterPage;
