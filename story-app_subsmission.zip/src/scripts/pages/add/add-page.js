import { postStory } from '../../data/api';

class AddPage {
  constructor() {
    this._videoStream = null;
    this._selectedLat = null;
    this._selectedLon = null;
  }

  async render() {
    const container = document.createElement('section');
    container.innerHTML = `
      <h2>Tambah Story</h2>
      <form id="add-story-form" aria-label="Form tambah story">
        <label for="name">Nama:</label>
        <input id="name" name="name" required />

        <label for="description">Deskripsi:</label>
        <textarea id="description" name="description" rows="4" required></textarea>

        <label for="photo">Upload Foto (atau ambil lewat kamera):</label>
        <input id="photo" name="photo" type="file" accept="image/*" />

        <div>
          <button type="button" id="start-camera">Buka Kamera</button>
          <button type="button" id="take-photo">Ambil Foto</button>
          <video id="camera-preview" autoplay playsinline style="display:none;width:100%;max-height:240px;border:1px solid #ccc;"></video>
          <canvas id="camera-canvas" style="display:none;"></canvas>
        </div>

        <label for="map-add">Pilih lokasi (klik di peta):</label>
        <div id="map-add" class="map-container" role="application" aria-label="Peta untuk memilih lokasi"></div>
        <input type="hidden" id="lat" name="lat" />
        <input type="hidden" id="lon" name="lon" />

        <div style="margin-top:.5rem">
          <button id="submit-btn" type="submit">Kirim</button>
        </div>
      </form>
      <div id="form-message" aria-live="polite"></div>
    `;
    return container;
  }

  async afterRender() {
    // setup map
    if (window.L) {
      this._map = L.map('map-add').setView([0,0],2);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(this._map);
      this._map.on('click', (e) => {
        const { lat, lng } = e.latlng;
        this._selectedLat = lat; this._selectedLon = lng;
        document.getElementById('lat').value = lat;
        document.getElementById('lon').value = lng;
        if (this._marker) this._map.removeLayer(this._marker);
        this._marker = L.marker([lat,lng]).addTo(this._map);
      });
    }

    // camera controls
    const startBtn = document.getElementById('start-camera');
    const takeBtn = document.getElementById('take-photo');
    const video = document.getElementById('camera-preview');
    const canvas = document.getElementById('camera-canvas');
    const photoInput = document.getElementById('photo');

    startBtn.addEventListener('click', async () => {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Media devices not supported in this browser.');
        return;
      }
      try {
        this._videoStream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = this._videoStream;
        video.style.display = 'block';
      } catch (err) {
        console.error(err);
        alert('Gagal membuka kamera.');
      }
    });

    takeBtn.addEventListener('click', () => {
      if (!this._videoStream) return alert('Kamera belum dibuka.');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);
      canvas.toBlob((blob) => {
        const file = new File([blob], 'capture.png', { type: 'image/png' });
        // set file to file input
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        photoInput.files = dataTransfer.files;
        // stop stream after capture
        this._videoStream.getTracks().forEach(t => t.stop());
        video.style.display = 'none';
      });
    });

    // form submit
    document.getElementById('add-story-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const description = document.getElementById('description').value.trim();
      const lat = document.getElementById('lat').value;
      const lon = document.getElementById('lon').value;
      const photoInputEl = document.getElementById('photo');

      if (!name || !description) {
        document.getElementById('form-message').textContent = 'Nama dan deskripsi wajib diisi.';
        return;
      }
      if (!photoInputEl.files.length) {
        document.getElementById('form-message').textContent = 'Harap unggah foto atau ambil lewat kamera.';
        return;
      }
      const formData = new FormData();
      formData.append('description', description);
      // API expects 'photo' and description; name is not required by API for stories but we include as description prefix
      formData.append('photo', photoInputEl.files[0]);
      if (lat && lon) {
        formData.append('lat', lat);
        formData.append('lon', lon);
      }

      try {
        const token = localStorage.getItem('authToken');
        const resp = await postStory(formData, token);
        if (resp.ok) {
          document.getElementById('form-message').textContent = 'Berhasil mengirim story.';
          document.getElementById('add-story-form').reset();
        } else {
          const txt = await resp.text();
          document.getElementById('form-message').textContent = 'Gagal mengirim: ' + txt;
        }
      } catch (err) {
        console.error(err);
        document.getElementById('form-message').textContent = 'Terjadi kesalahan saat mengirim.';
      }
    });
  }
}

export default AddPage;
