import L from 'leaflet';
import { fetchStories } from '../../data/api';
import { getRoute } from '../../routes/url-parser';

class HomePage {
  constructor() {
    this._map = null;
    this._markers = [];
  }

  async render() {
    const container = document.createElement('section');
    container.setAttribute('aria-live', 'polite');
    container.innerHTML = `
      <h2>Stories</h2>
      <div id="map" class="map-container" role="application" aria-label="Map showing story locations"></div>
      <div id="story-list" class="story-list" aria-label="List of stories"></div>
      <div id="story-warning" aria-live="polite"></div>
    `;
    return container;
  }

  async afterRender() {
    // fetch stories and render list + map
    const listEl = document.querySelector('#story-list');
    const warnEl = document.querySelector('#story-warning');
    try {
      const token = localStorage.getItem('authToken');
      // request with location=1 to get lat/lon when available
      const data = await fetchStories({ page:1, size:50, location:1, token });
      const stories = data.listStory || data.list || data.stories || [];
      if (!stories || stories.length === 0) {
        listEl.innerHTML = '<p>Tidak ada story untuk ditampilkan.</p>';
      } else {
        this._renderList(stories);
        this._initMap(stories);
      }
      warnEl.textContent = '';
    } catch (err) {
      console.error('fetchStories error:', err);
      // If unauthorized or API requires login, show helpful message and allow guest fallback
      const token = localStorage.getItem('authToken');
      if (!token) {
        warnEl.innerHTML = '<p role="alert">Anda belum login. Beberapa data (lokasi) mungkin tidak tersedia. Silakan <a href="#/login">login</a> atau <a href="#/register">daftar</a>.</p>';
      } else {
        warnEl.innerHTML = `<p role="alert">Gagal memuat data stories: ${String(err)}</p>`;
      }
      // Try to fetch stories without location as a fallback (some endpoints may allow public listing)
      try {
        const fallback = await fetchStories({ page:1, size:50, location:0, token: null });
        const stories2 = fallback.listStory || fallback.list || fallback.stories || [];
        if (stories2 && stories2.length) {
          this._renderList(stories2);
          this._initMap(stories2);
        } else {
          listEl.innerHTML = '<p>Tidak ada story untuk ditampilkan.</p>';
        }
      } catch (err2) {
        console.error('fallback fetch error:', err2);
        listEl.innerHTML = '<p role="alert">Gagal memuat data stories.</p>';
      }
    }
  }

  _renderList(stories) {
    const list = document.querySelector('#story-list');
    list.innerHTML = '';
    stories.forEach(story => {
      const card = document.createElement('article');
      card.className = 'story-card';
      card.tabIndex = 0;
      card.innerHTML = `
        <img src="${story.photoUrl || './public/images/logo.png'}" alt="${story.name || 'story image'}" />
        <h3>${story.name || 'Unknown'}</h3>
        <p>${story.description || ''}</p>
        <a href="#/stories/${story.id}" class="detail-link">Lihat detail</a>
      `;
      card.addEventListener('click', () => {
        if (story.lat && story.lon && this._map) {
          this._map.setView([story.lat, story.lon], 13);
        }
      });
      list.appendChild(card);
    });
  }

  _initMap(stories) {
    if (!window.L) return;
    if (!this._map) {
      this._map = L.map('map').setView([0,0], 2);
      // Tile layers
      const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(this._map);
      const topo = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenTopoMap contributors'
      });
      const satellite = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png');
      const baseLayers = {
        "OpenStreetMap": osm,
        "OpenTopoMap": topo,
        "Satellite": satellite
      };
      L.control.layers(baseLayers).addTo(this._map);
    }
    // add markers
    this._markers.forEach(m => this._map.removeLayer(m));
    this._markers = [];
    stories.forEach(s => {
      if (s.lat && s.lon) {
        const m = L.marker([s.lat, s.lon]).addTo(this._map).bindPopup(`<b>${s.name}</b><p>${s.description || ''}</p>`);
        this._markers.push(m);
      }
    });
    if (this._markers.length) {
      const group = L.featureGroup(this._markers);
      this._map.fitBounds(group.getBounds().pad(0.2));
    }
  }
}

export default HomePage;
