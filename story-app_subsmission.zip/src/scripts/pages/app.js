import routes from '../routes/routes';
import { getRoute } from '../routes/url-parser';

class App {
  constructor({ content }) {
    this._content = content;
  }

  async renderPage() {
    const pathname = window.location.hash.slice(1) || '/';
    const route = getRoute(pathname);
    const page = routes[route] || routes['/'];
    // Apply view transition if supported
    if (document.startViewTransition) {
      await document.startViewTransition(async () => {
        this._content.innerHTML = '';
        const element = await page.render();
        this._content.appendChild(element);
        if (page.afterRender) await page.afterRender();
      });
    } else {
      this._content.innerHTML = '';
      const element = await page.render();
      this._content.appendChild(element);
      if (page.afterRender) await page.afterRender();
    }
  }
}

export default App;
