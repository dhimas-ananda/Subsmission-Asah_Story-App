const CONFIG = {
  // Dicoding Story API base URL
  BASE_URL: 'https://story-api.dicoding.dev/v1',
};

export default CONFIG;
