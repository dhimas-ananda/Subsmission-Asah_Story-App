import CONFIG from '../config';

const ENDPOINTS = {
  BASE: `${CONFIG.BASE_URL}`,
  STORIES: `${CONFIG.BASE_URL}/stories`,
  STORIES_GUEST: `${CONFIG.BASE_URL}/stories/guest`,
  REGISTER: `${CONFIG.BASE_URL}/register`,
  LOGIN: `${CONFIG.BASE_URL}/login`,
  STORY_DETAIL: (id) => `${CONFIG.BASE_URL}/stories/${id}`,
};

export async function registerUser({ name, email, password }) {
  const resp = await fetch(ENDPOINTS.REGISTER, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });
  return resp.json();
}

export async function loginUser({ email, password }) {
  const resp = await fetch(ENDPOINTS.LOGIN, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return resp.json();
}

// fetch stories. options: { page, size, location (1/0), token }
export async function fetchStories({ page=1, size=20, location=0, token=null } = {}) {
  const params = new URLSearchParams();
  if (page) params.append('page', page);
  if (size) params.append('size', size);
  if (location !== null) params.append('location', location);
  const url = `${ENDPOINTS.STORIES}?${params.toString()}`;
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const resp = await fetch(url, { headers });
  if (!resp.ok) {
    const txt = await resp.text();
    throw new Error(txt || 'Failed to fetch stories');
  }
  const data = await resp.json();
  // Dicoding API returns listStory array when authorized, or maybe list depending
  return data;
}

export async function fetchStoryById(id, token=null) {
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const resp = await fetch(ENDPOINTS.STORY_DETAIL(id), { headers });
  if (!resp.ok) throw new Error('Failed to fetch story detail');
  return await resp.json();
}

export async function postStory(formData, token=null) {
  const headers = token ? { Authorization: `Bearer ${token}` } : {};
  const url = token ? ENDPOINTS.STORIES : ENDPOINTS.STORIES_GUEST;
  const resp = await fetch(url, {
    method: 'POST',
    headers,
    body: formData,
  });
  return resp;
}
