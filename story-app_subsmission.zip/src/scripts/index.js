import '../styles/styles.css';
import 'leaflet/dist/leaflet.css';

import App from './pages/app';
import L from 'leaflet';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

// Fix default icon urls that break when webpack bundles leaflet
L.Icon.Default.mergeOptions({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
});
function updateNav() {
  const nav = document.getElementById('main-nav');
  if (!nav) return;
  const token = localStorage.getItem('authToken');
  const user = localStorage.getItem('userName') || '';
  // clear current links then add base links
  nav.innerHTML = '';
  const links = [
    { href: '#/', label: 'Home' },
    { href: '#/add', label: 'Add Story' },
    { href: '#/about', label: 'About' },
  ];
  links.forEach(l => {
    const a = document.createElement('a');
    a.href = l.href;
    a.textContent = l.label;
    nav.appendChild(a);
  });
  if (token) {
    const span = document.createElement('span');
    span.style.marginLeft = '1rem';
    span.textContent = user;
    nav.appendChild(span);
    const logout = document.createElement('a');
    logout.href = '#/';
    logout.textContent = 'Logout';
    logout.style.marginLeft = '0.5rem';
    logout.addEventListener('click', (e) => {
      localStorage.removeItem('authToken');
      localStorage.removeItem('userName');
      updateNav();
    });
    nav.appendChild(logout);
  } else {
    const login = document.createElement('a');
    login.href = '#/login';
    login.textContent = 'Login';
    login.style.marginLeft = '1rem';
    nav.appendChild(login);
    const reg = document.createElement('a');
    reg.href = '#/register';
    reg.textContent = 'Register';
    reg.style.marginLeft = '0.5rem';
    nav.appendChild(reg);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  updateNav();
  const app = new App({
    content: document.querySelector('#main-content-inner'),
  });
  await app.renderPage();

  window.addEventListener('hashchange', async () => {
    updateNav();
    await app.renderPage();
  });
});