const CACHE_VERSION = 'v3';
const APP_SHELL = `app-shell-${CACHE_VERSION}`;
const API_CACHE = `story-api-${CACHE_VERSION}`;
const RUNTIME = `runtime-${CACHE_VERSION}`;
const IMAGE_CACHE = `images-${CACHE_VERSION}`;

const APP_SHELL_FILES = [
  '/',
  '/index.html'
];

self.addEventListener('install', (event) => {
  console.log('[SW] 📦 Installing...');
  self.skipWaiting();
  
  event.waitUntil(
    caches.open(APP_SHELL).then((cache) => {
      console.log('[SW] 💾 Caching app shell');
      return cache.addAll(APP_SHELL_FILES)
        .then(() => console.log('[SW] ✅ App shell cached'))
        .catch((err) => {
          console.error('[SW] ❌ Failed to cache app shell:', err);
        });
    })
  );
});

self.addEventListener('activate', (event) => {
  console.log('[SW] 🔄 Activating...');
  
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      const currentCaches = [APP_SHELL, API_CACHE, RUNTIME, IMAGE_CACHE];
      
      const cachesToDelete = cacheNames.filter(
        (name) => !currentCaches.includes(name)
      );
      
      await Promise.all(
        cachesToDelete.map((cacheName) => {
          console.log('[SW] 🗑️ Deleting old cache:', cacheName);
          return caches.delete(cacheName);
        })
      );
      
      await self.clients.claim();
      console.log('[SW] ✅ Activated and claimed clients');
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  if (req.method !== 'GET') {
    return;
  }

  if (url.origin.includes('story-api.dicoding.dev')) {
    event.respondWith(
      fetch(req)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.ok) {
            caches.open(API_CACHE).then((cache) => {
              cache.put(req, networkResponse.clone());
            });
          }
          return networkResponse;
        })
        .catch(async () => {
          const cache = await caches.open(API_CACHE);
          const cachedResponse = await cache.match(req);
          
          if (cachedResponse) {
            console.log('[SW] 💾 Serving API from cache (offline):', req.url);
            return cachedResponse;
          }
          
          console.log('[SW] ❌ No cache for API:', req.url);
          return new Response(
            JSON.stringify({
              error: true,
              message: 'Offline - data tidak tersedia',
              listStory: []
            }),
            {
              status: 200,
              headers: { 'Content-Type': 'application/json' }
            }
          );
        })
    );
    return;
  }

  if (url.origin === location.origin) {
    if (req.destination === 'document' || req.headers.get('accept')?.includes('text/html')) {
      event.respondWith(
        fetch(req)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.ok) {
              caches.open(RUNTIME).then((cache) => {
                cache.put(req, networkResponse.clone());
              });
            }
            return networkResponse;
          })
          .catch(async () => {
            const cachedResponse = await caches.match(req);
            if (cachedResponse) {
              console.log('[SW] 💾 Serving HTML from cache:', req.url);
              return cachedResponse;
            }
            
            const indexResponse = await caches.match('/index.html');
            if (indexResponse) {
              console.log('[SW] 🏠 Serving offline index.html');
              return indexResponse;
            }
            
            return new Response(
              `<!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Offline - Story App</title>
                <style>
                  body {
                    font-family: system-ui, -apple-system, sans-serif;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    height: 100vh;
                    margin: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    text-align: center;
                    padding: 1rem;
                  }
                  h1 { font-size: 3rem; margin: 0; }
                  p { font-size: 1.2rem; opacity: 0.9; }
                  .icon { font-size: 5rem; margin-bottom: 1rem; }
                </style>
              </head>
              <body>
                <div class="icon">📴</div>
                <h1>Anda Sedang Offline</h1>
                <p>Aplikasi tidak dapat diakses tanpa koneksi internet untuk pertama kali.</p>
                <p>Silakan periksa koneksi Anda dan coba lagi.</p>
              </body>
              </html>`,
              {
                headers: { 'Content-Type': 'text/html' }
              }
            );
          })
      );
      return;
    }

    if (
      url.pathname.endsWith('.js') ||
      url.pathname.endsWith('.css') ||
      url.pathname.endsWith('.woff') ||
      url.pathname.endsWith('.woff2') ||
      url.pathname.endsWith('.ttf')
    ) {
      event.respondWith(
        caches.match(req).then((cachedResponse) => {
          if (cachedResponse) {
            console.log('[SW] 💾 Serving from cache:', url.pathname);
            return cachedResponse;
          }

          return fetch(req)
            .then((networkResponse) => {
              if (networkResponse && networkResponse.ok) {
                caches.open(RUNTIME).then((cache) => {
                  cache.put(req, networkResponse.clone());
                  console.log('[SW] 💾 Cached:', url.pathname);
                });
              }
              return networkResponse;
            })
            .catch((err) => {
              console.error('[SW] ❌ Failed to fetch:', url.pathname, err);
              return new Response('', { status: 404, statusText: 'Not Found' });
            });
        })
      );
      return;
    }
  }

  if (
    req.destination === 'image' ||
    url.pathname.match(/\.(png|jpg|jpeg|webp|svg|gif|ico)$/)
  ) {
    event.respondWith(
      caches.open(IMAGE_CACHE).then((cache) =>
        cache.match(req).then((cachedResponse) => {
          if (cachedResponse) {
            console.log('[SW] 💾 Serving image from cache:', url.pathname);
            return cachedResponse;
          }

          return fetch(req)
            .then((networkResponse) => {
              if (networkResponse && networkResponse.ok) {
                cache.put(req, networkResponse.clone());
              }
              return networkResponse;
            })
            .catch(() => {
              console.log('[SW] 🖼️ Returning offline placeholder for:', url.pathname);
              return new Response(
                `<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
                  <rect width="400" height="300" fill="#e2e8f0"/>
                  <text x="50%" y="45%" text-anchor="middle" fill="#64748b" font-size="18" font-family="sans-serif">📷</text>
                  <text x="50%" y="60%" text-anchor="middle" fill="#64748b" font-size="14" font-family="sans-serif">Gambar Offline</text>
                </svg>`,
                { 
                  headers: { 
                    'Content-Type': 'image/svg+xml',
                    'Cache-Control': 'no-store'
                  } 
                }
              );
            });
        })
      )
    );
    return;
  }
});

self.addEventListener('sync', (event) => {
  console.log('[SW] 🔄 Sync event triggered:', event.tag);
  
  if (event.tag === 'outbox-sync') {
    event.waitUntil(flushOutboxFromSW());
  }
});

async function flushOutboxFromSW() {
  console.log('[SW] 📤 Flushing outbox...');
  
  try {
    const db = await openOutboxDB();
    const tx = db.transaction('outbox', 'readonly');
    const store = tx.objectStore('outbox');
    const allEntries = await getAllFromStore(store);
    
    console.log('[SW] 📦 Outbox entries found:', allEntries.length);
    
    if (allEntries.length === 0) {
      console.log('[SW] ✅ No entries in outbox');
      return;
    }
    
    let successCount = 0;
    
    for (const entry of allEntries) {
      try {
        console.log('[SW] 🔄 Syncing entry CID:', entry.cid);
        
        const fd = new FormData();
        
        for (const f of entry.formDataFields) {
          if (f.kind === 'file') {
            console.log('[SW] 📷 Restoring file:', f.filename);
            const bytes = atob(f.data);
            const arr = new Uint8Array(bytes.length);
            for (let i = 0; i < bytes.length; i++) {
              arr[i] = bytes.charCodeAt(i);
            }
            const blob = new Blob([arr], { type: f.type || 'image/jpeg' });
            fd.append(f.name, blob, f.filename || 'photo.jpg');
          } else {
            console.log('[SW] 📝 Restoring field:', f.name);
            fd.append(f.name, f.value);
          }
        }
        
        const headers = {};
        if (entry.token) {
          headers['Authorization'] = `Bearer ${entry.token}`;
        }
        
        console.log('[SW] 🚀 Posting to API...');
        const resp = await fetch('https://story-api.dicoding.dev/v1/stories', {
          method: 'POST',
          body: fd,
          headers
        });
        
        console.log('[SW] 📡 API response status:', resp.status);
        
        if (resp.ok) {
          console.log('[SW] ✅ Successfully synced entry CID:', entry.cid);
          await deleteFromOutboxDB(entry.cid);
          successCount++;
        } else {
          const errorText = await resp.text();
          console.error('[SW] ❌ Failed to sync entry:', resp.status, errorText);
        }
      } catch (err) {
        console.error('[SW] ❌ Error syncing entry:', err);
      }
    }
    
    if (successCount > 0) {
      await self.registration.showNotification('Story Disinkronkan ✅', {
        body: `${successCount} story offline berhasil dikirim`,
        icon: '/assets/icon-192.png',
        badge: '/assets/icon-64.png',
        tag: 'sync-success',
        silent: false,
        vibrate: [200, 100, 200]
      });
    }
    
    console.log('[SW] ✅ Outbox flush complete. Synced:', successCount);
  } catch (err) {
    console.error('[SW] ❌ Outbox flush error:', err);
  }
}

self.addEventListener('message', (event) => {
  console.log('[SW] 💬 Message received:', event.data);
  
  if (event.data === 'flush-outbox') {
    event.waitUntil(flushOutboxFromSW());
  }
  
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});

function openOutboxDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('story-idb', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('outbox')) {
        const store = db.createObjectStore('outbox', { 
          keyPath: 'cid', 
          autoIncrement: true 
        });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        console.log('[SW] 🗄️ Created outbox object store');
      }
      if (!db.objectStoreNames.contains('bookmarks')) {
        db.createObjectStore('bookmarks', { keyPath: 'id' });
        console.log('[SW] 🗄️ Created bookmarks object store');
      }
    };
  });
}

function getAllFromStore(store) {
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function deleteFromOutboxDB(cid) {
  const db = await openOutboxDB();
  const tx = db.transaction('outbox', 'readwrite');
  const store = tx.objectStore('outbox');
  
  return new Promise((resolve, reject) => {
    const request = store.delete(cid);
    request.onsuccess = () => {
      console.log('[SW] 🗑️ Deleted from outbox:', cid);
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

self.addEventListener('push', (event) => {
  console.log('[SW] 🔔 Push event received');
  
  let data = { 
    title: 'Story App', 
    body: 'Ada story baru', 
    icon: '/assets/icon-192.png', 
    data: { url: '/' } 
  };
  
  try { 
    if (event.data) {
      const parsed = event.data.json();
      if (parsed.title) data.title = parsed.title;
      if (parsed.options?.body) {
        data.body = parsed.options.body;
      } else if (parsed.body) {
        data.body = parsed.body;
      }
      if (parsed.options?.icon) data.icon = parsed.options.icon;
      if (parsed.options?.badge) data.badge = parsed.options.badge;
      if (parsed.data?.storyId) {
        data.data.url = `/#/story/${parsed.data.storyId}`;
      }
    }
  } catch (e) { 
    console.error('[SW] ❌ Parse push error:', e);
  }
  
  const options = {
    body: data.body || 'Ada story baru',
    icon: data.icon || '/assets/icon-192.png',
    badge: data.badge || '/assets/icon-64.png',
    data: data.data || { url: '/' },
    actions: [
      { action: 'open', title: 'Lihat Detail', icon: '/assets/icon-72.png' },
      { action: 'close', title: 'Tutup' }
    ],
    tag: 'story-notification',
    requireInteraction: false,
    vibrate: [200, 100, 200]
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title || 'Story App', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  console.log('[SW] 🖱️ Notification clicked, action:', event.action);
  event.notification.close();
  
  if (event.action === 'close') return;
  
  const url = event.notification.data?.url || '/';
  const fullUrl = self.location.origin + url;
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      for (const w of wins) {
        try {
          if (w.url === fullUrl && 'focus' in w) {
            return w.focus();
          }
        } catch (e) {}
      }
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});

console.log('[SW] 📝 Service Worker loaded');